package com.xnpool.data.sharesData;


public class SharesJob {

	public static void main(String[] args) {

		System.out.println("This is test job, please help me perfect it!");
	}

}
